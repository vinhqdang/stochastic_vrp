# Supplementary material

This archive accompanies the submission "Token-Efficient Context
Sharing in Multi-Agent LLM Systems: How Much Can Be Cut, and What
Limits It." It contains the code and logged data behind every table,
figure, and machine-checked claim in the paper, plus the raw output of
the four verification scripts. Nothing here is required to understand
the paper; it is provided for reproducibility.

## Contents

```
verification_output.txt   raw output of the four scripts below
code/
  musique_benchmark.py     main benchmark: policies, grids, scoring
  degradation_sweep.py     synthetic saturation sweep + Gemini API client
  embed_relevance.py       dense-embedding relevance scorer + cache
  allocation_experiment.py earlier single-dataset pilot (superseded by
                            musique_benchmark.py; kept for completeness)
  calibrate_difficulty.py  calibration helper for the synthetic sweep
  paired_test.py           McNemar exact test + paired bootstrap
  analyze_musique.py       aggregates the logged JSONL into the paper's
                            tables (dedupes on load; see header)
  separation_check.py      verifies Proposition 1 (parts a, b)
  unbounded_check.py       verifies Proposition 1(c) and Corollary 5
  decomposition_check.py   verifies Proposition 4 and Corollary 5's
                            approximation-transfer bound
  degeneracy_check.py      verifies Proposition 3 (both parameters)
  structure_check.py       additional structural sanity checks
  run_until_done.sh        drives a run across daily API-quota resets
  results/
    musique_*_lexical_*.jsonl    logged model calls (lexical scorer)
    sweep_gemini-3.5-flash-lite.jsonl   synthetic sweep log
    embed_cache.jsonl             cached embedding vectors (append-only)
    summary_musique.json          aggregated summary
```

## Mapping to the paper

- **Table 2, Table 3, Table 4** (main experimental grid, matched-budget
  comparisons, scaling with `n`): `musique_gemini-3.1-flash-lite_lexical_core.jsonl`
  and `musique_gemini-3.1-flash-lite_lexical_run1.jsonl`, analyzed by
  `analyze_musique.py`.
- **Table 5** (four value-curve designs for the marginal-allocation
  DP): produced by `musique_benchmark.py`'s `p_dp` policy across the
  same logged runs.
- **Table 6** (lexical vs. embedding scorer): `--dry-run` mode of
  `musique_benchmark.py` with `--scorer embed`, using the cached
  vectors in `embed_cache.jsonl` (no API calls needed to reproduce this
  table; the cache already contains every vector used).
- **Figure 2** (cost--quality frontier): the per-policy token/accuracy
  pairs in Table 3, plotted directly.
- **The two logged traces** in the Experiments section: reproducible
  from the same JSONL files by instance ID (search for
  `4hop2__161602_474028_88460_20985` and `3hop2__84553_90098_10557`).
- **Proposition 1** (the seed-set formulation loses a factor `n`, and
  is unbounded in general): `separation_check.py` (parts a, b) and
  `unbounded_check.py` (part c), both exhaustive over small instances.
- **Proposition 3** (neither toolchain's parameters exist): `degeneracy_check.py`,
  exhaustive over small ground sets.
- **Proposition 4 / Corollary 5** (exact decomposition and
  approximation transfer): `decomposition_check.py`, checked against
  brute-force enumeration.
- `verification_output.txt` is the literal stdout of running all four
  scripts, included so the claims can be inspected without executing
  anything.

## Reproducing without an API key

Item selection (which paragraphs each policy delivers, and their
token cost) is deterministic and requires no API access:

```
python3 musique_benchmark.py --dry-run
python3 musique_benchmark.py --dry-run --scorer embed
```

The four verification scripts are fully offline:

```
python3 separation_check.py
python3 unbounded_check.py
python3 decomposition_check.py
python3 degeneracy_check.py
```

Reproducing the model's answers (the accuracy numbers in Tables 2-4)
requires a Gemini API key set as an environment variable; see the
header of `degradation_sweep.py` for the exact variable names.

## Data provenance

The benchmark is MuSiQue-Ans (Trivedi et al., TACL 2022), released
under CC BY 4.0 and loaded via the HuggingFace `datasets` library
(`dgslibisey/MuSiQue`); it is not redistributed here. The JSONL files
in `code/results/` are our own logged policy outputs and model
answers on that public benchmark, keyed by the benchmark's own
instance IDs, and contain no personal or third-party data beyond what
MuSiQue itself publishes (its questions, answers, and Wikipedia-derived
paragraphs).
