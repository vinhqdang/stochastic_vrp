# Supplementary material

This archive accompanies the submission "Token-Efficient Context
Sharing in Multi-Agent LLM Systems: How Much Can Be Cut, and What
Limits It." It contains the code and logged data behind every table,
figure, and machine-checked claim in the paper, plus the raw output of
the verification scripts. Nothing here is required to understand the
paper; it is provided for reproducibility.

## Contents

```
verification_output.txt   raw output of the scripts below
logged_traces.md           the two traces referenced in the Experiments
                            section, with full item-by-item detail
code/
  musique_benchmark.py     main benchmark: policies, grids, scoring
  degradation_sweep.py     synthetic saturation sweep + Gemini API client
  embed_relevance.py       dense-embedding relevance scorer + cache
  allocation_experiment.py earlier single-dataset pilot (superseded by
                            musique_benchmark.py; kept for completeness)
  calibrate_difficulty.py  calibration helper for the synthetic sweep
  paired_test.py           McNemar exact test + paired bootstrap (flat,
                            receiver-level; superseded as primary by
                            cluster_test.py, kept for the receiver-level
                            comparison quoted in Table 2's caption)
  cluster_test.py          cluster-robust paired comparison (block
                            bootstrap + permutation test, resampling at
                            the source-instance level) -- the PRIMARY
                            statistic behind every CI/p in Table 2 and
                            in Section 7's cross-model comparison
  real_tokens.py           recomputes real Gemini countTokens counts for
                            the matched-budget grid (n=120), replacing
                            the word-count proxy in every reported token
                            figure; results/real_token_counts.jsonl is
                            its output
  value_curves_check.py    the three value-curve designs behind Table 5
                            (sum / noisy-OR / captured-mass), deterministic
                            recall plus real countTokens spend, on both
                            the plain and composite-receiver sets
  analyze_musique.py       aggregates the logged JSONL into the paper's
                            tables (dedupes on load; see header)
  separation_check.py      verifies Proposition 1 (parts a, b)
  unbounded_check.py       verifies Proposition 1(c) and Corollary 5
  decomposition_check.py   verifies Proposition 4 and Corollary 5's
                            approximation-transfer bound
  degeneracy_check.py      verifies Proposition 3 (both parameters, on
                            each witness and on the combined instance)
  structure_check.py       additional structural sanity checks
  run_until_done.sh        drives a run across daily API-quota resets
  results/
    musique_*_lexical_*.jsonl    logged model calls (lexical scorer)
    sweep_gemini-3.5-flash-lite.jsonl   synthetic sweep log
    embed_cache.jsonl             cached embedding vectors (append-only)
    summary_musique.json          aggregated summary (word-heuristic
                                   tokens; superseded by real_tokens.py
                                   for every number reported in the paper)
    real_token_counts.jsonl       real countTokens counts per (policy,
                                   cfg) on the n=120 grid
```

## Mapping to the paper

- **Table 2, Table 3** (the `n=120` matched-budget grid): item
  selection and model accuracy come from
  `musique_gemini-3.5-flash-lite_lexical_min.jsonl`; every token count
  and ratio reported in the paper is a real `countTokens` count from
  `real_tokens.py` (`results/real_token_counts.jsonl`), not the
  word-count proxy in `summary_musique.json` (kept only for the
  accuracy/delta numbers, which do not depend on the token-counting
  method). Table 2's CIs and `p`-values are `cluster_test.py`'s
  cluster-robust bootstrap and permutation test, run at 20,000
  iterations; `paired_test.py` gives the flat, receiver-level numbers
  Table 2's caption compares against.
- **Section 7's cross-model comparison** (oracle vs. broadcast on the
  second model): `cluster_test.py` on
  `musique_gemini-3.1-flash-lite_lexical_core.jsonl` (the 125-instance,
  4-arm confirmatory grid; one instance's run was cut short by API
  quota, leaving 124 complete instances / 248 receivers used in every
  paired comparison). The smaller, separate 19-instance, 12-arm pilot
  (`..._run1.jsonl`) is the source of the `5%` no-context accuracy
  figure quoted in Table 3's caption and the Discussion.
- **Table 5** (three value-curve designs for `musique_benchmark.py`'s
  `p_dp`-style marginal allocation, on plain and composite-receiver
  sets): `value_curves_check.py`, run with `--real-tokens` for the
  token column. A review found the prior version of this table
  unreproducible -- no code implementing three distinct curves survived
  in this repository -- so `value_curves_check.py` is a fresh,
  documented implementation, not a recovery of the old code; the
  numbers in the current paper are this script's output, not the
  previously published ones.
- **Table 6** (lexical vs. embedding scorer): `--dry-run` mode of
  `musique_benchmark.py` with `--scorer embed`, using the cached
  vectors in `embed_cache.jsonl` (no API calls needed to reproduce this
  table; the cache already contains every vector used).
- **Figure 2** (cost--quality frontier): the per-policy real-token/accuracy
  pairs in Table 3, plotted directly; the composite-receiver oracle/best-
  implementable-policy tokens quoted in the Discussion (Section 7) are
  also real `countTokens` counts, computed the same way as
  `value_curves_check.py`'s oracle and top-$10$ arms.
- **`logged_traces.md`**: the two traces referenced in the Experiments
  section, reproducible from
  `musique_gemini-3.1-flash-lite_lexical_run1.jsonl` and `..._core.jsonl`
  by instance ID (`4hop2__161602_474028_88460_20985` and
  `3hop2__84553_90098_10557`).
- **Proposition 1** (the seed-set formulation loses a factor `n`, and
  is unbounded in general): `separation_check.py` (parts a, b) and
  `unbounded_check.py` (part c and the approximation-transfer
  corollary), both exhaustive over small instances.
- **Proposition 3** (neither toolchain's parameters exist, on two
  separate witnesses, and on one combined two-item-per-receiver
  instance forcing both at once): `degeneracy_check.py`, exhaustive
  over small ground sets. The saturation witness matches the paper's
  explicit construction: `F={a,b}`, `rel=conf=|S|`,
  `rho(0)=0, rho(1)=0.5, rho(2)=3`.
- **Proposition 4 / Corollary 5** (exact decomposition and
  approximation transfer): `decomposition_check.py`, checked against
  brute-force enumeration.
- `verification_output.txt` is the literal stdout of running every
  script above, included so the claims can be inspected without
  executing anything (the two scripts needing a Gemini API key --
  `real_tokens.py` and `value_curves_check.py --real-tokens` -- have
  their output included too, since token counting is a lightweight
  `countTokens` call, not a billed generation call).

## Reproducing without an API key

Item selection (which paragraphs each policy delivers) and delivery
recall are deterministic and require no API access:

```
python3 musique_benchmark.py --dry-run
python3 musique_benchmark.py --dry-run --scorer embed
python3 value_curves_check.py
```

The exhaustive verification scripts are fully offline:

```
python3 separation_check.py
python3 unbounded_check.py
python3 decomposition_check.py
python3 degeneracy_check.py
```

`cluster_test.py` and `paired_test.py` are also offline (they read a
logged JSONL, no API calls):

```
python3 cluster_test.py results/musique_gemini-3.5-flash-lite_lexical_min.jsonl oracle broadcast
```

Reproducing the model's own answers (the accuracy numbers in Tables
2-4) requires a Gemini API key set as an environment variable; see the
header of `degradation_sweep.py` for the exact variable names. Real
token counts (`real_tokens.py`, `value_curves_check.py --real-tokens`)
need the same key but only call the lightweight `countTokens` endpoint,
not `generateContent`.

## Data provenance

The benchmark is MuSiQue-Ans (Trivedi et al., TACL 2022), released
under CC BY 4.0 and loaded via the HuggingFace `datasets` library
(`dgslibisey/MuSiQue`); it is not redistributed here. The JSONL files
in `code/results/` are our own logged policy outputs and model
answers on that public benchmark, keyed by the benchmark's own
instance IDs, and contain no personal or third-party data beyond what
MuSiQue itself publishes (its questions, answers, and Wikipedia-derived
paragraphs).
