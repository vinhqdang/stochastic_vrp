"""Allocation policies on a PUBLIC benchmark: MuSiQue-Ans.

WHY A PUBLIC BENCHMARK
----------------------
`allocation_experiment.py` runs on a task we wrote, which invites the
obvious objection that we evaluated on our own benchmark. This runs the
same policies on MuSiQue-Ans (Trivedi et al., TACL 2022, CC BY 4.0),
where the structure PARCEL needs is ANNOTATED IN THE DATA rather than
constructed by us:

  fact pool  = the 20 `paragraphs`, each carrying `is_supporting`
  agents     = the `question_decomposition` sub-questions, each carrying
               `paragraph_support_idx` -- the one paragraph answering it
  cost       = tokens actually transmitted, summed over agents

Ground-truth relevance is labelled, so an oracle allocation is
computable and every policy can be scored against it.

WHAT IS OURS AND MUST BE DISCLOSED
----------------------------------
MuSiQue is published as a SINGLE-agent QA task. Splitting it across
per-sub-question agents is our framing, not a native property, and the
paper must say so.

Most MuSiQue decompositions are sequential -- sub-question 2 reads
"#1 >> spouse", referencing hop 1's answer -- which is a pipeline, not
parallel receivers. We therefore restrict to the BRANCHING families
(3hop2, 4hop2, 4hop3), where two sub-questions carry no back-reference
and are genuinely independent. Verified on the dev split: all 351 such
instances have exactly 2 independent sub-questions. The 2hop family is
retained as a single-receiver ablation.

CONTAMINATION
-------------
MuSiQue predates these models and its single-hop seeds overlap
SQuAD/NQ, so some answers are memorised. Two consequences, both handled
rather than hoped away:

  1. Memorisation COMPRESSES our effect -- a model answering from
     parametric memory does not need the gold paragraph, so starving an
     agent looks as good as feeding it. This biases AGAINST the method,
     making any positive result conservative.
  2. It is NOT arm-neutral. Memorised recall degrades more in long
     distractor-heavy contexts than in short clean ones, so a small
     -budget arm could win partly through a memory channel unrelated to
     our mechanism.

The `none` policy is therefore not merely a floor, it is the
contamination control: question only, zero paragraphs. Any sub-question
answered correctly with no context at all is memorised, and the analysis
reports results both with and without those instances.

Report POLICY DELTAS, never absolute EM.

USAGE
  python3 musique_benchmark.py --dry-run              # free, no API
  python3 musique_benchmark.py --instances 150
"""

import argparse
import json
import os
import pathlib
import random
import re
import string
import sys
from concurrent.futures import ThreadPoolExecutor

sys.path.insert(0, str(pathlib.Path(__file__).parent))
from degradation_sweep import call_gemini, TOKENS_PER_WORD  # noqa: E402

RESULTS = pathlib.Path(__file__).parent / "results"
BRANCHING = {"3hop2", "4hop2", "4hop3"}
STOP = set("""a an the of in on at to for and or is was were be been by with
from as that this it its his her their who whom which what when where how
did does do done "" '' s""".split())


def load_instances(limit, family="branching", seed=0):
    from datasets import load_dataset
    ds = load_dataset("dgslibisey/MuSiQue", split="validation")
    want = BRANCHING if family == "branching" else {"2hop"}
    rows = []
    for r in ds:
        if r["id"].split("__")[0] not in want:
            continue
        indep = [q for q in r["question_decomposition"]
                 if "#" not in q["question"]]
        if len(indep) < 2:
            continue
        rows.append({
            "id": r["id"],
            "paragraphs": [{"idx": p["idx"], "title": p["title"],
                            "text": p["paragraph_text"],
                            "gold": bool(p["is_supporting"])}
                           for p in r["paragraphs"]],
            "agents": [{"q": q["question"], "answer": q["answer"],
                        "needs": q["paragraph_support_idx"]}
                       for q in indep],
            "full_q": r["question"],
            "full_a": r["answer"],
        })
    random.Random(seed).shuffle(rows)
    rows = rows[:limit] if limit else rows
    return rows


def add_composite_receivers(rows):
    """Add a receiver holding the FULL multi-hop question.

    WHY. Proposition 1's advantage grows with receiver HETEROGENEITY,
    and the branching subset has none: every sub-question receiver needs
    exactly one paragraph, so a uniform per-receiver allowance is
    already near-optimal and there is nothing for marginal allocation to
    exploit. That is why the DP only tied.

    MuSiQue supplies grounded heterogeneity without inventing a task.
    Its top-level `question` requires ALL supporting paragraphs, so a
    receiver holding it needs 2-4 items where a sub-question receiver
    needs 1. A single global k must then either starve the composite
    receiver or overfeed the simple ones -- precisely the failure the
    per-receiver formulation is supposed to avoid.

    `needs_all` marks the composite receiver so recall is scored
    all-or-nothing: a multi-hop question is not answerable from a subset
    of its hops, and scoring it fractionally would hide the effect.
    """
    out = []
    for inst in rows:
        gold = [p["idx"] for p in inst["paragraphs"] if p.get("gold")]
        if len(gold) < 2:
            continue
        agents = [dict(a, needs_all=[a["needs"]]) for a in inst["agents"]]
        agents.append({"q": inst["full_q"], "answer": inst["full_a"],
                       "needs": gold[0], "needs_all": list(gold),
                       "composite": True})
        out.append(dict(inst, agents=agents))
    return out


def merge_instances(rows, m, seed=0):
    """Fuse m instances into one allocation problem with 2m receivers.

    WHY. Proposition 1 says the advantage of per-receiver allocation over
    one-set-for-everyone grows as Theta(n). A single MuSiQue instance has
    only 2 independent receivers, each needing exactly 1 paragraph, so
    the receivers are nearly symmetric and a uniform allowance is already
    near-optimal -- there is no heterogeneity for marginal allocation to
    exploit, and measurement at n=2 cannot see the effect the theory
    predicts.

    Merging m instances gives 2m receivers over a shared pool of 20m
    paragraphs. Receivers now differ sharply in how peaked their
    relevance scores are: some have one obvious candidate, others a flat
    and misleading spread. That difference is what a per-receiver budget
    can act on and a global k cannot.

    This is OUR construction and must be disclosed as such. It changes
    the retrieval difficulty (a 20m-paragraph pool is harder than 20),
    which is why every policy is re-measured on the merged instances
    rather than compared across merge levels.
    """
    rng = random.Random(seed)
    out = []
    for i in range(0, len(rows) - m + 1, m):
        chunk = rows[i:i + m]
        paras, agents, offset = [], [], 0
        for inst in chunk:
            remap = {}
            for p in inst["paragraphs"]:
                remap[p["idx"]] = offset
                paras.append({**p, "idx": offset})
                offset += 1
            for a in inst["agents"]:
                agents.append({**a, "needs": remap[a["needs"]]})
        rng.shuffle(paras)
        out.append({"id": "+".join(c["id"] for c in chunk),
                    "paragraphs": paras, "agents": agents})
    return out


def norm(s):
    s = s.lower().strip()
    s = "".join(c for c in s if c not in string.punctuation)
    s = re.sub(r"\b(a|an|the)\b", " ", s)
    return " ".join(s.split())


def em(pred, gold):
    """Exact match after MuSiQue-style normalisation, plus containment.

    Containment is included because a model may answer "Steve Hillage,
    the performer" where the gold is "Steve Hillage". Being strict there
    would penalise every arm equally but add noise for no gain.
    """
    p, g = norm(pred), norm(gold)
    return bool(g) and (p == g or g in p)


def tokens_of(par):
    return max(1, round(len(par["text"].split()) * TOKENS_PER_WORD))


# Swapped at runtime by --scorer embed. Kept module-level so the policy
# functions stay pure lookups and the two scorers are exactly comparable.
SCORER = None


def relevance(par, agent):
    """Relevance signal. Lexical by default; embeddings via --scorer embed.

    Both are imperfect on purpose -- a real router has an approximate
    scorer, not gold labels.
    """
    if SCORER is not None:
        return SCORER(par, agent)
    return _lexical(par, agent)


def _lexical(par, agent):
    """Cheap bag-of-words overlap."""
    q = set(re.findall(r"[a-z0-9]+", agent["q"].lower())) - STOP
    t = set(re.findall(r"[a-z0-9]+",
                       (par["title"] + " " + par["text"]).lower())) - STOP
    if not q or not t:
        return 0.0
    return len(q & t) / (len(q) ** 0.5 * len(t) ** 0.5)


def rho_prime(load, c_star, scale):
    """Marginal saturation cost: rises to c*, then flattens (PROJECT.md 11.1)."""
    x = load / c_star
    return scale * (2.0 * x) / (1.0 + x * x)


def auto_scale(densities, quantile=0.5):
    """Set the saturation price in the units of THIS pool.

    Hand-picking `scale` is not portable: MuSiQue paragraphs are ~10x
    larger than the synthetic facts, so relevance densities shift by an
    order of magnitude and a constant tuned on one dataset cuts delivery
    off immediately on the other. That is a calibration artefact, not a
    property of the rule.

    Instead, anchor the price so that at load = c* it equals a quantile
    of the candidate pool's own density distribution. The rule then
    reads "stop once the marginal item is no better than a typical
    candidate", which is scale-free and needs no per-dataset tuning --
    an advantage over top-k, whose k must be tuned per dataset.

    Uses only the candidate densities, never the gold labels.
    """
    vals = sorted(d for d in densities if d > 0)
    if not vals:
        return 0.0
    return vals[min(len(vals) - 1, int(quantile * len(vals)))]


# ---------------------------------------------------------------- policies

def p_broadcast(inst, **_):
    ids = [p["idx"] for p in inst["paragraphs"]]
    return {i: list(ids) for i, _ in enumerate(inst["agents"])}


def p_none(inst, **_):
    return {i: [] for i, _ in enumerate(inst["agents"])}


def p_oracle(inst, **_):
    """Exactly what each receiver needs -- all of it.

    Returning a single paragraph capped the ceiling at 0.67 once
    composite receivers existed, because a multi-hop receiver needs
    every supporting paragraph. The oracle is the upper bound, so
    getting this wrong understates what allocation can achieve.
    """
    return {i: list(a.get("needs_all", [a["needs"]]))
            for i, a in enumerate(inst["agents"])}


def p_random(inst, k=3, rng=None, **_):
    ids = [p["idx"] for p in inst["paragraphs"]]
    return {i: rng.sample(ids, min(k, len(ids)))
            for i, _ in enumerate(inst["agents"])}


def p_centrality(inst, k=3, **_):
    """The classical-IM answer: one globally-ranked seed set for everyone."""
    score = {p["idx"]: sum(relevance(p, a) for a in inst["agents"])
             for p in inst["paragraphs"]}
    top = sorted(score, key=score.get, reverse=True)[:k]
    return {i: list(top) for i, _ in enumerate(inst["agents"])}


def p_topk(inst, k=3, **_):
    """Per-agent relevance ranking. The single-price baseline."""
    out = {}
    for i, a in enumerate(inst["agents"]):
        ranked = sorted(inst["paragraphs"],
                        key=lambda p: relevance(p, a) / tokens_of(p),
                        reverse=True)
        out[i] = [p["idx"] for p in ranked[:k]]
    return out


def p_parcel(inst, lam=0.0, c_star=1500.0, q=0.5, **_):
    """Two prices: a global budget price, and the receiver's own rising one.

    `lam` is the global budget price (swept to trace the frontier); the
    saturation price is self-calibrating via auto_scale, so the rule
    carries no dataset-specific constant.
    """
    out = {}
    for i, a in enumerate(inst["agents"]):
        dens = {p["idx"]: relevance(p, a) / tokens_of(p)
                for p in inst["paragraphs"]}
        scale = auto_scale(dens.values(), q)
        ranked = sorted(inst["paragraphs"], key=lambda p: dens[p["idx"]],
                        reverse=True)
        chosen, load = [], 0.0
        for p in ranked:
            if dens[p["idx"]] >= lam + rho_prime(load, c_star, scale):
                chosen.append(p["idx"])
                load += tokens_of(p)
        out[i] = chosen
    return out


def p_dp(inst, per_recv=200, bins=24, sat=0.0, **_):
    """MARGINAL ALLOCATION: split one global budget across receivers.

    This is the algorithm the separation result implies, and it is
    structurally different from every baseline here.

    The objective is separable across receivers and coupled only by the
    shared budget, so the problem factors: build each receiver's own
    value-versus-budget curve, then solve a resource-allocation DP for
    the split that maximises the total. The DP equalises MARGINAL value
    per token across receivers instead of giving each the same
    allowance.

    Top-k cannot do this: one global k spends the same on a receiver
    whose best candidate is obvious and on one whose candidates are
    uniformly mediocre. Greedy pricing cannot either -- it accumulates
    per receiver against a threshold with no view of what the budget
    would buy elsewhere.

    `sat` optionally charges a per-receiver saturation penalty on the
    chosen level. It enters only through the level, so it may be any
    shape at all -- convex, a cliff, non-monotone. The greedy admission
    price needs rho convex for its rising-bar argument, and the measured
    curves are S-shaped rather than convex, so this is where the two
    algorithms genuinely differ.
    """
    # `per_recv` is the average allowance per receiver, so the pool
    # scales with n and the comparison against a per-receiver top-k is
    # at matched spend. (Passing a fixed TOTAL made the DP compete at a
    # fraction of top-k's budget once receivers were merged.)
    budget = per_recv * len(inst["agents"])
    step = max(1, budget // bins)
    levels = [b * step for b in range(bins + 1)]

    # Per-receiver value curve: greedily fill by relevance density, which
    # is exact for a modular relevance and near-optimal for a submodular
    # one, then subtract the level's saturation charge.
    curves = []
    for a in inst["agents"]:
        # Per-receiver value is the estimated CHANCE the receiver holds
        # what it needs, as a noisy-OR over normalised scores -- not the
        # sum of scores. This matters: a sum is near-linear in budget, so
        # the DP had nothing to balance and simply poured tokens into
        # receivers with many mediocre-but-scoring candidates, starving
        # ones with a single sharply-peaked correct match. A noisy-OR is
        # concave and saturating, so marginal value per token falls as a
        # receiver fills, which is exactly the quantity the DP should be
        # equalising across receivers.
        raw = {p["idx"]: max(0.0, relevance(p, a)) for p in inst["paragraphs"]}
        tot = sum(raw.values()) or 1.0
        q = {k: v / tot for k, v in raw.items()}          # label-free
        ranked = sorted(inst["paragraphs"],
                        key=lambda p: q[p["idx"]] / tokens_of(p),
                        reverse=True)
        row = []
        for lvl in levels:
            got, spend, mass = [], 0, 0.0
            for p in ranked:
                t = tokens_of(p)
                if spend + t > lvl:
                    continue
                got.append(p["idx"])
                spend += t
                mass += q[p["idx"]]
            row.append((mass - sat * spend, list(got)))
        curves.append(row)

    n = len(inst["agents"])
    NEG = float("-inf")
    dp = [[NEG] * (bins + 1) for _ in range(n + 1)]
    pick = [[None] * (bins + 1) for _ in range(n + 1)]
    for b in range(bins + 1):
        dp[n][b] = 0.0
    for i in range(n - 1, -1, -1):
        for b in range(bins + 1):
            for spend in range(b + 1):
                v, ids = curves[i][spend]
                nxt = dp[i + 1][b - spend]
                if nxt == NEG:
                    continue
                if v + nxt > dp[i][b]:
                    dp[i][b] = v + nxt
                    pick[i][b] = (spend, ids)

    out, b = {}, bins
    for i in range(n):
        spend, ids = pick[i][b]
        out[i] = ids
        b -= spend
    return out


POLICIES = {"broadcast": p_broadcast, "dp": p_dp, "none": p_none, "oracle": p_oracle,
            "random": p_random, "centrality": p_centrality,
            "topk": p_topk, "parcel": p_parcel}

CONFIGS_FULL = (
    [("broadcast", {}), ("none", {}), ("oracle", {})]
    + [("random", {"k": k}) for k in (1, 3, 6)]
    + [("centrality", {"k": k}) for k in (1, 3, 6)]
    + [("topk", {"k": k}) for k in (1, 2, 3, 5, 10)]
    + [("parcel", {"q": q}) for q in (0.95, 0.85, 0.7, 0.5, 0.3)]
    + [("dp", {"per_recv": b}) for b in (60, 120, 200, 350, 550)]
)

# The Gemini free tier allows 500 requests/day PER MODEL. The full grid
# is 19 configs x 2 agents = 38 calls per instance, which buys only ~13
# instances a day. This trimmed grid keeps one point per baseline family
# plus the frontier points that matter -- 12 configs, 24 calls per
# instance -- so ~20 instances fit inside one model's daily allowance.
CONFIGS_MIN = (
    [("broadcast", {}), ("none", {}), ("oracle", {})]
    + [("random", {"k": 3}), ("centrality", {"k": 3})]
    + [("topk", {"k": k}) for k in (1, 3, 5, 10)]
    + [("parcel", {"q": q}) for q in (0.95, 0.7, 0.3)]
    + [("dp", {"per_recv": b}) for b in (120, 200, 350, 550)]
)

# For the POWERED test, only the four arms that carry the claims. At 8
# calls per instance instead of 24, one model's 500/day allowance buys
# ~60 instances rather than ~20 -- and power on these four comparisons
# is what decides whether the mechanism separates from a tuned top-k.
#   broadcast  the cost baseline
#   oracle     the ceiling, and the contamination-free upper bound
#   topk k=5   the single-price baseline at its best observed setting
#   parcel     the two-price rule at its most permissive setting
CONFIGS_CORE = [("broadcast", {}), ("oracle", {}),
                ("topk", {"k": 5}), ("parcel", {"q": 0.3})]

# Head-to-head at MATCHED spend: the single comparison that decides
# whether marginal allocation beats a tuned global k. topk k=5 spends
# ~411 tokens/agent, dp per_recv=350 spends ~324 -- so the DP is given
# LESS budget, not more, and any accuracy win is not bought with tokens.
CONFIGS_HEAD = [("broadcast", {}), ("oracle", {}), ("none", {}),
                ("topk", {"k": 5}), ("dp", {"per_recv": 350}),
                ("topk", {"k": 3}), ("dp", {"per_recv": 200})]

CONFIGS = CONFIGS_MIN


def build_prompt(inst, idx_list, agent, rng):
    by_idx = {p["idx"]: p for p in inst["paragraphs"]}
    paras = [by_idx[j] for j in idx_list if j in by_idx]
    rng.shuffle(paras)
    if paras:
        ctx = "\n\n".join(f"[{p['title']}] {p['text']}" for p in paras)
    else:
        ctx = "(no documents provided)"
    return (f"{ctx}\n\nQuestion: {agent['q']}\n\n"
            f"Answer from the documents above. If the answer is not there, "
            f"reply UNKNOWN. Reply with only the answer, no explanation.\n"
            f"End your reply with the line: ANSWER: <answer>")


def extract(reply):
    if reply.startswith("__ERROR__"):
        return None
    m = re.search(r"ANSWER:\s*(.+)", reply, re.IGNORECASE)
    return (m.group(1) if m else reply.strip().splitlines()[-1]).strip()


def dry_run(rows):
    """Tokens and gold-recall per policy. No API calls."""
    print(f"{'policy':11s} {'cfg':>14s} {'tok/agent':>10s} {'recall':>8s}")
    for name, kw in CONFIGS:
        tok = rec = n = 0
        for inst in rows:
            alloc = POLICIES[name](inst, rng=random.Random(0), **kw)
            by_idx = {p["idx"]: p for p in inst["paragraphs"]}
            for i, a in enumerate(inst["agents"]):
                ids = alloc[i]
                tok += sum(tokens_of(by_idx[j]) for j in ids if j in by_idx)
                need = a.get("needs_all", [a["needs"]])
                rec += 1.0 if all(j in ids for j in need) else 0.0
                n += 1
        print(f"{name:11s} {json.dumps(kw):>14s} {tok / n:10.0f} {rec / n:8.2f}")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--model", default="gemini-3.5-flash-lite")
    ap.add_argument("--instances", type=int, default=150)
    ap.add_argument("--composite", action="store_true",
                    help="add a receiver holding the full multi-hop "
                         "question, which needs ALL supporting paragraphs "
                         "-- creates the receiver heterogeneity Prop 1 "
                         "predicts the advantage from")
    ap.add_argument("--merge", type=int, default=1,
                    help="fuse m instances into one problem with 2m "
                         "receivers (Prop 1 predicts the gap grows with n)")
    ap.add_argument("--family", default="branching",
                    choices=["branching", "2hop"])
    ap.add_argument("--workers", type=int, default=3)
    ap.add_argument("--out", default=None)
    ap.add_argument("--scorer", default="lexical",
                    choices=["lexical", "embed"],
                    help="relevance signal: bag-of-words, or cached "
                         "embedding cosine (recommended)")
    ap.add_argument("--grid", default="min", choices=["core", "min", "full", "head"],
                    help="core=4 arms (8 calls/instance -- best power per "
                         "unit of the 500/day/model allowance); min=12; "
                         "full=19")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    global CONFIGS
    CONFIGS = {"core": CONFIGS_CORE, "min": CONFIGS_MIN,
               "full": CONFIGS_FULL, "head": CONFIGS_HEAD}[args.grid]
    rows = load_instances(args.instances, args.family)
    if args.composite:
        rows = add_composite_receivers(rows)
    if args.merge > 1:
        rows = merge_instances(rows, args.merge)
    print(f"{len(rows)} instances, "
          f"{sum(len(r['agents']) for r in rows)} agents, "
          f"{sum(len(r['paragraphs']) for r in rows) // max(len(rows),1)} "
          f"paragraphs/instance")

    if args.scorer == "embed":
        global SCORER
        from embed_relevance import build_scorer
        print("embedding paragraphs and sub-questions (cached on disk)...")
        SCORER = build_scorer(rows)
        print("scorer ready")

    if args.dry_run:
        dry_run(rows)
        return

    key = os.environ.get("GEMINI_API_KEY")
    if not key:
        sys.exit("set GEMINI_API_KEY")

    tag = args.model.replace("/", "-")
    suffix = "c" if args.composite else ""
    out = (pathlib.Path(args.out) if args.out
           else RESULTS / f"musique_{tag}_{args.scorer}_{args.grid}_m{args.merge}{suffix}.jsonl")
    out.parent.mkdir(parents=True, exist_ok=True)

    # Resume: skip work already present in the output file. Runs stop when
    # a daily allowance runs out, so re-running with fresh keys is the
    # normal path -- without this it redoes everything and appends
    # duplicate rows, which would silently double-count in the analysis.
    done = set()
    if out.exists():
        with open(out) as fh:
            for line in fh:
                try:
                    r = json.loads(line)
                except json.JSONDecodeError:
                    continue          # tolerate a torn final line
                if r.get("correct") is not None:
                    done.add((r["id"], r["policy"], r["cfg"], r["agent"]))
    if done:
        print(f"resuming: {len(done)} calls already recorded")

    jobs, meta = [], []
    for inst in rows:
        by_idx = {p["idx"]: p for p in inst["paragraphs"]}
        for name, kw in CONFIGS:
            alloc = POLICIES[name](inst, rng=random.Random(hash(inst["id"]) % 9),
                                   **kw)
            for i, a in enumerate(inst["agents"]):
                if (inst["id"], name, json.dumps(kw), i) in done:
                    continue
                ids = alloc[i]
                jobs.append(build_prompt(inst, ids, a, random.Random(i)))
                meta.append({"id": inst["id"], "policy": name,
                             "cfg": json.dumps(kw), "agent": i,
                             "tokens": sum(tokens_of(by_idx[j])
                                           for j in ids if j in by_idx),
                             "n_sent": len(ids),
                             "had_gold": all(
                                 j in ids
                                 for j in a.get("needs_all", [a["needs"]])),
                             "composite": bool(a.get("composite")),
                             "gold": a["answer"], "model": args.model})

    print(f"{len(jobs)} calls -> {out}")
    with open(out, "a") as fh, ThreadPoolExecutor(args.workers) as pool:
        for n, (m, reply) in enumerate(
                zip(meta, pool.map(lambda p: call_gemini(args.model, p, key),
                                   jobs)), 1):
            if reply.startswith("__QUOTA__"):
                # Daily free-tier quota gone. Continuing only burns
                # wall-clock and writes junk rows; the partial file up to
                # here is still usable.
                print(f"\nQUOTA EXHAUSTED for {args.model} after {n - 1} "
                      f"calls; partial results kept.", file=sys.stderr)
                break
            pred = extract(reply)
            rec = dict(m)
            rec["pred"] = (pred or "")[:120]
            rec["correct"] = None if pred is None else em(pred, m["gold"])
            fh.write(json.dumps(rec) + "\n")
            fh.flush()
            if n % 50 == 0:
                print(f"  {n}/{len(jobs)}", file=sys.stderr, flush=True)
    print("done")


if __name__ == "__main__":
    main()
