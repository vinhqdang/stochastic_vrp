# Logged traces

Two individual calls from the matched-budget grid, referenced from the
main text's Experiments section ("Logged traces"), tracing the
mechanism down to the model's own answer rather than only reporting
aggregates. Both are real logged calls, not constructed illustrations;
reproducible from the committed JSONL plus `code/musique_benchmark.py`
(item selection is deterministic and needs no API call; only
reproducing the model's own answer would).

## Trace 1 — over-delivery misleads, not just wastes

Instance `4hop2__161602_474028_88460_20985`, receiver 0: sub-question
"Who hosted the tournament?", gold answer "Thailand," supporting
paragraph idx 17.

- **Broadcast** (all 20 paragraphs, 2297 tokens): the model answers
  "Russia" — wrong, drawn off by unrelated candidates.
- **Oracle** (1 paragraph, 43 tokens, 53x cheaper): the model answers
  "Thailand" — correct.

Fewer tokens, a better answer, on one logged call rather than an
aggregate statistic. Source:
`results/musique_gemini-3.1-flash-lite_lexical_run1.jsonl` and
`..._core.jsonl`.

## Trace 2 — the seed set starves a receiver

Instance `3hop2__84553_90098_10557`. Receiver 0 needs paragraph idx 2
("Charlemagne"); receiver 1 needs paragraph idx 0 ("Sylvester").

- **Seed set / centrality at k=3** sends the identical set
  `{Holy Roman Emperor, Rover SD1, Charlemagne}` to both receivers.
  Receiver 0 is covered by luck; receiver 1's needed paragraph never
  appears — `Rover SD1` (a car marque) matched receiver 1's query
  lexically through unrelated word overlap and occupied the slot
  instead. Logged answer: receiver 0 correct, receiver 1 "UNKNOWN."
- **Per-receiver top-3**, at nearly the same total budget (517 vs. 588
  tokens), delivers `{Sylvester, Gaius Julius Priscus, Maria Theresa
  of Naples and Sicily}` to receiver 1, and both receivers answer
  correctly.

One global set cannot serve two different needs at this cost; two
different sets can, for the same cost. This is Proposition 1's
mechanism showing up in an actual model call, not just in the
aggregate 19.2-point effect reported in Table 2 of the main text.
Source: `results/musique_gemini-3.1-flash-lite_lexical_run1.jsonl`
(`centrality` k=3 and `topk` k=3 rows for this id).
